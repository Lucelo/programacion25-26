package Nave;

public class Nave {

    String Nombre;

    Deposito[] depositos;

    int rellenarDeposito;

    Nave(String nave){
        this.Nombre =nave;
        this.depositos=new Deposito[5];


    }


    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String nombre) {
        Nombre = nombre;
    }

    public boolean cargarDeposito(int indice, Cartucho c){

        if (rellenarDeposito < indice){




        }





    }

    public int saltarHiperespacio(){

    if(){

    }else if(){

    }else if(){

    }


    }



}
