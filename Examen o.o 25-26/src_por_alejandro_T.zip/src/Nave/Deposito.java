package Nave;

public class Deposito {








    public agregarCartucho(Cartucho c){





    }

    public  calcularPotenciaTotal(){



    }

    public   calcularPesoTotal(){



    }

    public  contarCartuchosDeTipo(String tipo){

        for (int i = 0; i < 3; i++) {



        }

    }

    public  calcularPesoCartuchoTipo(String tipo){


    }









}
