package excepciones;

public class NaveException extends RuntimeException {
    public NaveException(String message) {
        super(message);
    }
}
