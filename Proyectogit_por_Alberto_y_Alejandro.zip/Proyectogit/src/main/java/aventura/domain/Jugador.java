package aventura.domain;

import aventura.exceptions.AventuraException;

import java.util.ArrayList;
import java.util.List;

public class Jugador {

    private String nombre;
    private List<Objeto> inventario;
    private String habitacionActual;

    /**
     * Constructor de la clase Jugador.
     *
     * @param nombre Nombre del jugador.
     */
    public Jugador(String nombre, String habitacionActual) {
        this.nombre = nombre;
        this.habitacionActual = habitacionActual;
        this.inventario = new ArrayList<>();
    }


    public void setInventario(List<Objeto> inventario) {
        this.inventario = inventario;
    }

    /**
     * Getters y Setters
     */
    public String getNombre() {
        return nombre;
    }

    public List<Objeto> getInventario() {
        return inventario;
    }

    public String getHabitacionActual() {
        return habitacionActual;
    }

    /**
     * Método para que el jugador coja un objeto.
     *
     * @param objeto Objeto a coger.
     * @throws AventuraException Si el objeto no es inventariable o el inventario está lleno.
     */
    public void coger(Objeto objeto) throws AventuraException {
        /*
        Para poder coger un objeto, deben pasar dos cosas:
        1. Que el objeto sea Inventariable
        2. Que haya espacio en el inventario
        */

        if (!(objeto instanceof Inventariable)) {
            throw new AventuraException("El objeto %s no se puede coger.".formatted(objeto.getNombre()));
        }
        inventario.add(objeto);
    }

    /**
     * Método para eliminar un objeto del inventario.
     *
     * @param objeto Objeto a eliminar.
     * @return true si se eliminó el objeto, false si no se encontró.
     */
    public boolean eliminarDeInventario(Objeto objeto) {
        return inventario.remove(objeto);
    }

    /**
     * Busca un objeto en el inventario por su nombre.
     *
     * @param nombre Nombre del objeto a buscar.
     * @return El objeto si se encuentra, null en caso contrario.
     */
    public Objeto buscarEnInventario(String nombre) {
        for (Objeto objeto : inventario) {
            if (objeto.getNombre().toLowerCase().contains(nombre.toLowerCase())) {
                return objeto;
            }
        }
        return null;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setHabitacionActual(String siguienteId) {
        this.habitacionActual = siguienteId;
    }
}
