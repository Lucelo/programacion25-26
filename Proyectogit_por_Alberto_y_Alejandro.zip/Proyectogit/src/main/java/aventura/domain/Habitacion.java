package aventura.domain;

import aventura.exceptions.AventuraException;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Habitacion implements Serializable {
    private final long SerialVersionUID = 1L;


    private String id;
    private String descripcion;
    List<Objeto> objetos;

    private Map<String, String> salidas;

    /**
     * Constructor de la clase Habitacion.
     *
     * @param desc Descripción de la habitación.
     */
    public Habitacion(String id, String desc) {
        this.id = id;
        this.descripcion = desc;
        this.objetos = new ArrayList<>();
        this.salidas = new HashMap<>();
    }

    public void ajustaSalida(String direccion, String idDestino) {
        salidas.put(direccion.toLowerCase(), idDestino);
    }

    public String idDestino(String direccion) {
        return salidas.get(direccion.toLowerCase());
    }

    /**
     * Agrega un objeto a la habitación.
     *
     * @param obj Objeto a agregar.
     * @throws AventuraException Si no se puede agregar el objeto.
     */
    public void agregarObjeto(Objeto obj) {
        objetos.add(obj);
    }

    /**
     * Elimina un objeto de la habitación.
     *
     * @param obj Objeto a eliminar.
     * @return true si se eliminó el objeto, false si no se encontró.
     */
    public void eliminarObjeto(Objeto obj) {
        objetos.remove(obj);
    }

    /**
     * Muestra la descripción de la habitación y los objetos presentes en ella.
     *
     * @return Descripción de la habitación y lista de objetos.
     */
    public String mirar() {
        StringBuilder sb = new StringBuilder();
        sb.append(this.descripcion).append("\n");
        for (Objeto obj : objetos) {
            if (obj != null) {
                sb.append(" - ").append(obj.getNombre()).append("\n");
            }
        }
        return sb.toString();
    }

    /**
     * Obtiene los objetos presentes en la habitación.
     *
     * @return Array de objetos en la habitación.
     */
    public List<Objeto> getObjetos() {
        return objetos;
    }

    public String getId() {
        return id;
    }

    public Map<String, String> getSalidas() {
        return salidas;
    }

    /**
     * Busca un objeto por su nombre en la habitación.
     *
     * @param nombre Nombre del objeto a buscar.
     * @return El objeto si se encuentra, null en caso contrario.
     */

    public Objeto buscar(String nombre) {
        return objetos.stream()
                .filter(o -> o.getNombre().toLowerCase().contains(nombre.toLowerCase()))
                .findFirst()
                .orElse(null);
    }

    public void setSalidas(Map<String, String> salidas) {
        this.salidas = salidas;
    }
}
