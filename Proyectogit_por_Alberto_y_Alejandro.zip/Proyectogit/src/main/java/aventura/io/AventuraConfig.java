package aventura.io;

import aventura.domain.Habitacion;

import java.util.HashMap;
import java.util.Map;

/**
 * Clase que representa la configuración del juego de aventuras.
 * Contiene una descripción del juego y un conjunto de habitaciones.
 */
public class AventuraConfig {
    // Descripción general del juego (nombre, info, etc.)
    private String descripcionJuego;

    // Mapa de habitaciones: clave = ID de la habitación, valor = objeto Habitacion
    private Map<String, Habitacion> habitaciones;

    /**
     * Constructor que inicializa la configuración del juego.
     *
     * @param descripcionJuego Texto descriptivo del juego
     * @param mapa             Mapa con las habitaciones del juego
     */
    public AventuraConfig(String descripcionJuego, Map<String, Habitacion> mapa) {
        this.descripcionJuego = descripcionJuego;
        this.habitaciones = getHabitaciones();
        mapa = new HashMap<>();
    }

    // Devuelve la descripcion del juego
    public String getDescripcionJuego() {
        return descripcionJuego;
    }

    //Devuelve el mapa de habitaciones
    public Map<String, Habitacion> getHabitaciones() {
        return habitaciones;
    }
}
