package aventura.io;

import aventura.domain.Habitacion;
import aventura.domain.Objeto;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

public class Migrador {
    public static void main(String[] args) {
        List<Habitacion> habitacionesViejas = new ArrayList<>();
        try {
            migrar(habitacionesViejas);
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * Migra una lista de habitaciones antiguas a un nuevo formato JSON.
     *
     * @param habitacionesViejas Lista de habitaciones a migrar
     * @throws IOException Si ocurre un error al leer o escribir archivos
     */
    public static void migrar(List<Habitacion> habitacionesViejas) throws IOException {
        // Se crea un mapa donde la clave es el ID de la habitación
        // y el valor es la propia habitación
        Map<String, Habitacion> mapa = new HashMap<>();
        for (Habitacion h : habitacionesViejas) {
            mapa.put(h.getId(), h);
        }
        // Se crea la configuración del juego con un nombre y el mapa de habitaciones
        AventuraConfig config = new AventuraConfig("Mi juego de aventuras", mapa);
        // Objeto para cargar propiedades desde el archivo config.properties
        Properties props = new Properties();
        // Variables para guardar las rutas del directorio y archivo final
        Path directorioBase;
        Path archivoBase;
        // Se lee el archivo de configuración (config.properties)
        try (BufferedReader reader = Files.newBufferedReader(Paths.get("config.properties"))) {
            props.load(reader);
        }
        // Se obtiene la ruta del directorio base desde las propiedades
        String dir = props.getProperty("juego.directorio.base");
        // Se obtiene el nombre del archivo base desde las propiedades
        String archivo = props.getProperty("juego.archivo.base");
        // Se construye la ruta del directorio
        directorioBase = Paths.get(dir);
        //Se construye la ruta completa del archivo (directorio + nombre archivo)
        archivoBase = directorioBase.resolve(archivo);
        // Se crea el objeto Gson para convertir a JSON
        Gson gson = new GsonBuilder()
                .registerTypeAdapter(Objeto.class, new ObjetoAdapter())
                .setPrettyPrinting()
                .create();
        // Se crea el escritor de archivo
        FileWriter writer = null;
        writer = new FileWriter(archivoBase.toFile());
        // Se convierte el objeto config a JSON y se escribe en el archivo
        gson.toJson(config, writer);
        // Se cierra el archivo
        writer.close();
    }
}
