package aventura.io;

import aventura.domain.Objeto;
import com.google.gson.*;

import java.lang.reflect.Type;
import java.time.LocalDate;

/**
 * Adaptador personalizado para la clase Objeto.
 * Permite serializar y deserializar objetos teniendo en cuenta herencia,
 * añadiendo un campo "tipo" en el JSON para identificar la clase concreta.
 */
public class ObjetoAdapter implements JsonSerializer<Objeto>, JsonDeserializer<Objeto> {

    // Ruta base del paquete donde están las clases hijas de Objeto
    private static final String PAQUETE_DOMAIN = "aventura.domain";

    /**
     * Convierte un JSON en un objeto de tipo Objeto (o una de sus subclases).
     */
    @Override
    public Objeto deserialize(JsonElement jsonElement, Type type, JsonDeserializationContext jsonDeserializationContext) throws JsonParseException {
        // Se obtiene el JSON como objeto
        JsonObject jsonObject = jsonElement.getAsJsonObject();

        // Se comprueba que exista el campo "tipo"
        if (!jsonObject.has("tipo")) {
            throw new JsonParseException("Error: El Json no contiene el campo tipo");
        }

        // Se obtiene el nombre de la clase concreta (ej: "Llave", "Espada", etc.)
        String nombreClase = jsonObject.get("tipo").getAsString();

        try {
            // Se construye dinámicamente la clase completa con su paquete
            Class<?> claseDestino = Class.forName(PAQUETE_DOMAIN + nombreClase);

            // Se deserializa el JSON a esa clase concreta
            return jsonDeserializationContext.deserialize(jsonObject, claseDestino);

        } catch (ClassNotFoundException e) {
            // Error si no existe la clase indicada

            throw new JsonParseException("No se encontró la clase hija" + PAQUETE_DOMAIN + nombreClase, e);
        }
    }

    /**
     * Convierte un objeto (de tipo Objeto o subclase) a JSON.
     */
    @Override
    public JsonElement serialize(Objeto objeto, Type type, JsonSerializationContext context) {
        // Se convierte el objeto a JSON de forma normal
        JsonObject jsonObject = context.serialize(objeto).getAsJsonObject();

        // Se añade el campo "tipo" con el nombre de la clase concreta
        jsonObject.addProperty("tipo", objeto.getClass().getSimpleName());

        // Se devuelve el JSON final
        return jsonObject;
    }
}
