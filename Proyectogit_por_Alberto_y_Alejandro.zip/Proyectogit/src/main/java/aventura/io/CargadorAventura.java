package aventura.io;

import aventura.domain.Objeto;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;

public class CargadorAventura {

    // Gson configurado para poder deserializar objetos del juego
    private Gson gson;

    // Directorio base donde se encuentran los archivos del juego
    private Path directorioBase;

    // Ruta completa del archivo principal del mundo (aventura.json)
    private Path archivoBase;

    /**
     * Constructor del cargador de la aventura.
     * Inicializa Gson y registra el adaptador necesario para convertir
     * los objetos del JSON a clases Java concretas del juego.
     */
    public CargadorAventura() {
        gson = new GsonBuilder()
                .registerTypeAdapter(Objeto.class, new ObjetoAdapter())
                .create();
    }

    /**
     * Carga la configuración del juego desde el archivo config.properties.
     * Este archivo define las rutas externas del juego (directorio y archivo base).
     *
     * @throws IOException si el archivo de configuración no existe o no se puede leer
     */
    public void cargarConfiguracion() throws IOException {
        Properties props = new Properties();

        // Lectura del archivo de configuración
        try (BufferedReader reader = Files.newBufferedReader(Paths.get("config.properties"))) {
            props.load(reader);
        }

        // Obtiene el directorio base del juego desde el properties
        String dir = props.getProperty("juego.directorio.base");

        // Obtiene el nombre del archivo principal del mundo (JSON)
        String archivo = props.getProperty("juego.archivo.base");

        // Construcción de la ruta base del proyecto
        directorioBase = Paths.get(dir);

        // Construcción de la ruta completa del archivo del mundo
        archivoBase = directorioBase.resolve(archivo);
    }

    /**
     * Carga el mundo del juego desde el archivo JSON principal.
     * Convierte el archivo JSON en un objeto AventuraConfig usando Gson.
     *
     * @return configuración completa del juego (habitaciones, descripción, etc.)
     * @throws IOException si el archivo del mundo no existe o no se puede leer
     */
    public AventuraConfig cargarMundoBase() throws IOException {
        try (BufferedReader reader = Files.newBufferedReader(archivoBase)) {
            return gson.fromJson(reader, AventuraConfig.class);
        }
    }
}